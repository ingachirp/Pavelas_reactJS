export default function Total(props) {
  console.log("Total component");
  return <b>Total button pressed: {props.buttonPressed}</b>;
}
